library(shiny)
library(shinydashboard)
library(datasets)
library(plotly)

# Define UI for application that draws a histogram
shinyUI(
    dashboardPage(
        
        # Application title
        dashboardHeader(title = "Demystify Data"),
        
        # Sidebar with a slider input for number of bins 
        dashboardSidebar( 
            sidebarMenu(
                menuItem("Dashboard", tabName = 'dashboard', icon = icon('dashboard')),
                menuItem(text = 'Regression',
                         tabName = "regression",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Simple Regression", 
                                     tabName = 'simpleregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "Multiple Regression", 
                                     tabName = 'multipleregression',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Classification',
                         tabName = "classification",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Logistic Regression", 
                                     tabName = 'logisticregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "KNN", 
                                     tabName = 'knn',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Clustering',
                         tabName = "clustering",
                         icon = icon("clipboard"),
                         menuSubItem(text = "K Mean", 
                                     tabName = 'kmean',
                                     icon = icon('line-chart')),
                         menuSubItem("Multiple Regression", 
                                     tabName = 'multipleregression',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Data', tabName = 'dataview', icon = icon("database"))
            )
            , collapsed = TRUE
        ),
        dashboardBody(
            tabItems(
                tabItem(tabName = "dashboard",
                        # First Row
                        div(class = "well", "Div content"),
                        fluidRow(
                            box(title = 'Regression', width = 4, htmlOutput('plot1'),
                                status = "info", solidHeader = T, collapsible = T),
                            box(title = 'Classification', width = 4, htmlOutput('plot2'),
                                status = "success", solidHeader = T, collapsible = T),
                            box(title = 'Clustering', width = 4, htmlOutput('plot3'),
                                status = "warning", solidHeader = T, collapsible = T)
                        ),
                        
                        ## Second Row
                        fluidRow(
                            tabBox(id = 'tabchart1',
                                   tabPanel("Tab 1", tabName='tab1',"This is Tab 1"),
                                   tabPanel("Tab 2", tabName='tab2',"This is Tab 2"),
                                   tabPanel("Tab 3", tabName='tab3',"This is Tab 3"),width = 6
                            )
                            
                        )
                        
                ),
                tabItem(tabName = "about", p("This example of about")),
                tabItem(tabName = "about", p("This example of about")),
                tabItem(tabName = "dataview", dataTableOutput("viewdata"))
            )
        )
    )
)