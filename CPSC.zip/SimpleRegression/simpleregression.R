## Simple Regression

df <- read.csv("homeprices.csv")
df
