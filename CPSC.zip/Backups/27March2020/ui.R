library(shiny)
library(shinydashboard)
library(shinythemes)
library(datasets)
library(plotly)
library(ggplot2)
library(factoextra)
library(NbClust)
library(naniar)
library(caTools)
theme_set(theme_bw())

# Define UI for application that draws a histogram
shinyUI(
    dashboardPage(
        
        # Application title
        dashboardHeader(title = "Demystify Data"),
        
        # Sidebar with a slider input for number of bins 
        dashboardSidebar( 
            sidebarMenu(
                menuItem("Dashboard", tabName = 'dashboard', icon = icon('dashboard')),
                menuItem(text = 'Regression',
                         tabName = "regression",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Simple Regression", 
                                     tabName = 'simpleregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "Multiple Regression", 
                                     tabName = 'multipleregression',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Classification',
                         tabName = "classification",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Logistic Regression", 
                                     tabName = 'logisticregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "KNN", 
                                     tabName = 'knn',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Clustering',
                         tabName = "clustering",
                         icon = icon("clipboard"),
                         menuSubItem(text = "K-Means", 
                                     tabName = 'kmeans',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Data', tabName = 'dataview', icon = icon("database"))
            )
            , collapsed = TRUE
        ),
        dashboardBody(
            tags$head(
                tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
            ),
            tabItems(
                tabItem(tabName = "dashboard",
                        # First Row
                        # fluidRow(
                        #     valueBox(2, "Number of Algorithms", icon = icon("bezier-curve"), color = "purple"),
                        #     valueBox(10 * 2, "Coffee", icon = icon("coffee"), color = "yellow"),
                        #     valueBox(5, "Team Members", icon = icon("users")),
                        # ),
                        fluidRow(
                            box(title = 'Regression', width = 4, htmlOutput('plot1'),
                                status = "info", solidHeader = T, collapsible = T),
                            box(title = 'Classification', width = 4, htmlOutput('plot2'),
                                status = "success", solidHeader = T, collapsible = T),
                            box(title = 'Clustering', width = 4, htmlOutput('plot3'),
                                status = "warning", solidHeader = T, collapsible = T),
                            
                            column(10,offset = 1,
                                tags$img(src="images/dashboard.png", width="100%")
                            )
                        ),
                        
                        helpText("Note: The tool is in the beta version and is tested for only for specific datasets. Please refresh the tool if you find any discrepancy.")
                        
                ),
                ### Simple Regression starts here
                tabItem(tabName = "simpleregression",
                        style = "height:auto",
                        div(class = "well", "Simple"),
                        fluidRow(
                            # column allocation for widgets
                            column(6,
                                   fileInput("simpleregfile","Upload the file"), # fileinput() function is used to get the file upload contorl option
                                   helpText("Default max. file size is 5MB"),
                            ),
                            column(3,
                                   h5(helpText("Select the read.table parameters below")),
                                   checkboxInput(inputId = 'header', label = 'Header', value = TRUE),
                                   checkboxInput(inputId = "stringAsFactors", "stringAsFactors", FALSE),
                                   
                            ),
                            column(3,
                                   radioButtons(inputId = 'sep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = "output.fileUploaded",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("varx")
                                       
                                ),
                                column(5,
                                       uiOutput("vary")
                                ),
                                column(2,
                                       actionButton("simpleregrun", "Run"),
                                )
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = ("input.simpleregrun == 1"),
                                tabBox(id = 'simpleregtab',
                                    tabPanel("Summary", tabName='simpleregsum',
                                             verbatimTextOutput("simpleregsum")),
                                    tabPanel("Data", tabName='simpleregdata',
                                             tableOutput("simpleregdata")),width = 12
                                    )
                            ),
                        
                        ),
                ### Simple Regression ends here
                
                ### Multiple Regression starts here
                tabItem(tabName = "multipleregression", 
                        div(class = "well", "Multiple Regression"),
                        fluidRow(
                            # column allocation for widgets
                            column(6,
                                   fileInput("multiregfile","Upload the file"),
                                   helpText("Default max. file size is 5MB"),
                                   ),
                            column(3,
                                   h5(helpText("Select the read.table parameters below")),
                                   checkboxInput(inputId = 'multiheader', label = 'Header', value = TRUE),
                                   checkboxInput(inputId = "multistringAsFactors", "stringAsFactors", FALSE),
                                   ),
                            column(3,
                                   radioButtons(inputId = 'multisep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                                   )
                            ),
                        
                        conditionalPanel(
                            condition = "output.multifileUploaded == true",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("multivarx")
                                       
                                ),
                                column(5,
                                       uiOutput("multivary")
                                ),
                                column(2,
                                       actionButton("multiregrun", "Run"),
                                ),
                                column(5,
                                       textOutput("multiregvarx")
                                ),
                                column(5,
                                       textOutput("multiregvary")
                                ),
                            )
                            
                        ),
                        hr(),
                        conditionalPanel(
                            condition = ("input.multiregrun == 1"),
                            tabBox(id = 'multiregtab',
                                   tabPanel("Summary", tabName='multiregsum',
                                            verbatimTextOutput("multiregsum")),
                                   tabPanel("Data", tabName='multiregdata',
                                            tableOutput("multiregdata")),width = 12
                            )
                        ),
                       
                        ),
                ### Multiple Regression ends here
                
                ### K-mean starts here
                tabItem(tabName = "kmeans",
                            div(class = "well", "K Means"),
                            fluidRow(class="uploadfeature",
                                # column allocation for widgets
                                column(6,
                                       fileInput("kmeansfile","Upload the file"),
                                       helpText("Default max. file size is 5MB"),
                                ),
                                column(3,
                                       h5(helpText("Select the read.table parameters below")),
                                       checkboxInput(inputId = 'kmeansheader', label = 'Header', value = TRUE),
                                       checkboxInput(inputId = "kmeansstringAsFactors", "stringAsFactors", FALSE),
                                ),
                                column(3,
                                       radioButtons(inputId = 'kmeanssep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                                )
                            ),
                            conditionalPanel(
                                condition = "output.kmeansfileUploaded",
                                hr(),
                                fluidRow(
                                    class="selectfeature",
                                    # column allocation for widgets
                                    column(6,
                                           uiOutput("kmeansx")
                                           
                                    ),
                                    
                                    column(3,
                                           h5(helpText("Scale the dataset")),
                                           checkboxInput(inputId = 'kmeansscale', label = 'Scale', value = TRUE)
                                    ),
                                    
                                    column(2,
                                           actionButton("kmeansevaluate", "Evaluate the dataset"),
                                    ),
                                    column(12,
                                           uiOutput("kmeansvarx")
                                    )
                                    
                                ),
                                fluidRow(
                                    # column allocation for widgets
                                    column(12,
                                           uiOutput("Hopkins")
                                    ),
                                ),
                                
                            ),
                           
                        conditionalPanel(
                            condition = ("input.getclusterbutton > 0"),
                            hr(),
                            fluidRow(
                                class="getnumberofcluster",
                                # column allocation for widgets
                                
                                       box(title = "Elbow method",solidHeader = TRUE,
                                           plotOutput("elbowmethood", height = 250)
                                       ),
                                       
                                
                                
                                       box(title = "Silhouette Methood",solidHeader = TRUE,
                                           plotOutput("silhouettemethood", height = 250)
                                       ),
                                       
                                
                                column(4,
                                       textInput("numberofclusters", "Enter the number of clusters"),
                                ),
                                column(4,
                                       textInput("numberofnstarts", "Enter the number of nstart "),
                                ),
                                column(4,
                                       actionButton("numberofclustersaction", "Run the model"),
                                )
                            )
                            ),
                        
                        conditionalPanel(
                            condition = ("input.numberofclustersaction > 0"),
                            hr(),
                            fluidRow(
                                class="knnoutput",
                                # column allocation for widgets
                                
                                column(6,
                                       verbatimTextOutput("knnoutputsummary")
                                       
                                ),
                                box(title = "Cluster Plot",solidHeader = TRUE,
                                    plotOutput("knnoutputplot", height = 350)
                                    ),
                                       
                            )
                        )
                        
                        
                        ),
                ### K-mean starts here
                
                ### Logistic Regression starts here
                tabItem(tabName = "logisticregression",
                        div(class = "well", "Logistic Regression"),
                        fluidRow(class="uploadfeature",
                                 # column allocation for widgets
                                 column(6,
                                        fileInput("lrfile","Upload the file"),
                                        helpText("Default max. file size is 5MB"),
                                 ),
                                 column(3,
                                        h5(helpText("Select the read.table parameters below")),
                                        checkboxInput(inputId = 'lrheader', label = 'Header', value = TRUE),
                                        checkboxInput(inputId = "lrstringAsFactors", "stringAsFactors", FALSE),
                                 ),
                                 column(3,
                                        radioButtons(inputId = 'lrsep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                                 )
                        ),
                        
                        conditionalPanel(
                            condition = "output.lrfileUploaded",
                            hr(),
                            div(class = "well", "Explanatory Data Analysis"),
                            
                                tabsetPanel(#type="tab", 
                                            tabPanel("Structure", verbatimTextOutput("edastr")),
                                            tabPanel("Summary", verbatimTextOutput("edasummary")),
                                            tabPanel("Data", tableOutput("edadata")),
                                            tabPanel("Missing Data", plotOutput("edamissingdata"))
                                            
                                ),
                            hr(),
                            fluidRow(
                                class="selectfeature",
                                # column allocation for widgets
                                column(6,
                                       uiOutput("lrx") 
                                ),
                                
                                
                                column(6,
                                       uiOutput("lry")
                                       
                                ),
                                
                                column(6,
                                       textInput("trainingsplit", "Split the dataset into training"),
                                ),
                                
                                column(3,
                                       actionButton("lrmodelbutton", "Run the model"),
                                )
                                
                                
                            ),
                            
                        ),
                        
                        conditionalPanel(
                            condition = ("input.lrmodelbutton > 0"),
                            hr(),
                            #helpText("Output will be displayed here"),
                            fluidRow(
                                class="lrmodeloutput",
                                # column allocation for widgets
                                box(title = "Model Summary",solidHeader = TRUE,
                                    verbatimTextOutput("lrmodelsummary")
                                )
                                
                            )
                        )
                        
                )
            ),
            
            
        )
    )
)