library(shiny)
# Define server logic required to draw a histogram
shinyServer(function(input, output, session){
    data <- reactive({
        file1 <- input$file
        if(is.null(file1)){return()} 
        df <- read.csv(file=file1$datapath, sep=input$sep, header = input$header, stringsAsFactors = input$stringAsFactors)
        return(df)
    })
    
    output$fileUploaded <- reactive({
        return(!is.null(data()))
    })
    outputOptions(output, 'fileUploaded', suspendWhenHidden=FALSE)
    
    
    
    # Pulling the list of variable for choice of variable x
    output$varx <- renderUI({
        selectInput("simpleregvarx",
                    "Select the inputs for the Independent Variable",
                    choices=names(data()),
                    multiple = T)
    })
    
    # Pulling the list of variable for choice of variable y
    output$vary <- renderUI({
        selectInput("simpleregvary", 
                    "Select the inputs for the Dependent Variable", 
                    choices=names(data()))
        
    })
    
    output$selectvariables <- reactive({
        return(!is.null(data()))
    })
    
    outputOptions(output, 'selectvariables', suspendWhenHidden=FALSE)
    
    
    
    output$simpleregvarx <- renderText({
        paste(input$simpleregvarx)
    })
    
    output$simpleregvary <- renderText({
        paste(input$simpleregvary)
    })
    
    output$simpleregsum <- renderPrint({
        req(data())
        if(input$simpleregrun == 0)
            return()
        else
            x <- data()[,input$simpleregvarx]
        y <- data()[,input$simpleregvary]
        lm1 <- lm(x~y, data = data())
        #model <- lm(data()[,input$simpleregvarx] ~ data()[,input$simpleregvary], data = df())
        #lm1 <- reactive({lm(reformulate(data()[,input$simpleregvarx], data()[,input$simpleregvary]), data = RegData)})
        #lm(data()[,input$simpleregvarx] ~ data()[,input$simpleregvary], data=data())
        #hist(data()[,input$simpleregvarx])
        summary(lm1)
    })
    
    output$simpleregsum <- renderPrint({
        req(data())
        if(input$simpleregrun == 0)
            return()
        else
            x <- data()[,input$simpleregvarx]
        y <- data()[,input$simpleregvary]
        lm1 <- lm(x~y, data = data())
        #model <- lm(data()[,input$simpleregvarx] ~ data()[,input$simpleregvary], data = df())
        #lm1 <- reactive({lm(reformulate(data()[,input$simpleregvarx], data()[,input$simpleregvary]), data = RegData)})
        #lm(data()[,input$simpleregvarx] ~ data()[,input$simpleregvary], data=data())
        #hist(data()[,input$simpleregvarx])
        summary(lm1)
    })
    
    output$simpleregstr <- renderPrint({
        req(data())
        if(input$simpleregrun == 0)
            return()
        else
            summary(data())
    })
    
    output$simpleregdata <- renderTable({
        req(data())
        if(input$simpleregrun == 0)
            return()
        else
            head(data())
    })
    
    
    output$plot1 <- renderText({
        paste("<ul>
              <li>Simple Regression</li>
              <li>Multiple Regression</li>
              </ul>")
    })
    
    output$plot2 <- renderText({
        paste("<ul>
              <li>Simple Regression</li>
              <li>Multiple Regression</li>
              </ul>")
    })
    output$plot3 <- renderText({
        paste("<ul>
              <li>Simple Regression</li>
              <li>Multiple Regression</li>
              </ul>")
    })
    
})

