library(shiny)
library(shinydashboard)
library(shinythemes)
library(datasets)
library(plotly)

# Define UI for application that draws a histogram
shinyUI(
    dashboardPage(
        
        # Application title
        dashboardHeader(title = "Demystify Data"),
        
        # Sidebar with a slider input for number of bins 
        dashboardSidebar( 
            sidebarMenu(
                menuItem("Dashboard", tabName = 'dashboard', icon = icon('dashboard')),
                menuItem(text = 'Regression',
                         tabName = "regression",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Simple Regression", 
                                     tabName = 'simpleregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "Multiple Regression", 
                                     tabName = 'multipleregression',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Classification',
                         tabName = "classification",
                         icon = icon("clipboard"),
                         menuSubItem(text = "Logistic Regression", 
                                     tabName = 'logisticregression',
                                     icon = icon('line-chart')),
                         menuSubItem(text = "KNN", 
                                     tabName = 'knn',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Clustering',
                         tabName = "clustering",
                         icon = icon("clipboard"),
                         menuSubItem(text = "K Mean", 
                                     tabName = 'kmean',
                                     icon = icon('line-chart')),
                         menuSubItem("Multiple Regression", 
                                     tabName = 'multipleregression',
                                     icon = icon('line-chart'))
                ),
                menuItem(text = 'Data', tabName = 'dataview', icon = icon("database"))
            )
            , collapsed = TRUE
        ),
        dashboardBody(
            tabItems(
                tabItem(tabName = "dashboard",
                        # First Row
                        div(class = "well", "Div content"),
                        fluidRow(
                            box(title = 'Regression', width = 4, htmlOutput('plot1'),
                                status = "info", solidHeader = T, collapsible = T),
                            box(title = 'Classification', width = 4, htmlOutput('plot2'),
                                status = "success", solidHeader = T, collapsible = T),
                            box(title = 'Clustering', width = 4, htmlOutput('plot3'),
                                status = "warning", solidHeader = T, collapsible = T)
                        ),
                        
                        ## Second Row
                        fluidRow(
                            tabBox(id = 'tabchart1',
                                   tabPanel("Tab 1", tabName='tab1',"This is Tab 1"),
                                   tabPanel("Tab 2", tabName='tab2',"This is Tab 2"),
                                   tabPanel("Tab 3", tabName='tab3',"This is Tab 3"),width = 6
                            )
                            
                        )
                        
                ),
                tabItem(tabName = "multipleregression",
                        div(class = "well", "Multiple Regression"),
                        fluidRow(
                            column(6,
                                   fileInput("multiregfile","Upload the file"),
                                   helpText("Default max. file size is 5MB"),
                            ),
                            column(3,
                                   h5(helpText("Select the read.table parameters below")),
                                   checkboxInput(inputId = 'multiregheader', label = 'Header', value = TRUE),
                                   checkboxInput(inputId = "multiregstringAsFactors", "stringAsFactors", FALSE),
                                   
                            ),
                            column(3,
                                   radioButtons(inputId = 'multiregsep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = "output.multiregfileUploaded",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("multiregvarx")
                                       
                                ),
                                column(5,
                                       uiOutput("multiregvary")
                                ),
                                column(2,
                                       uiOutput("multiregsubmit")
                                ),
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = "output.multiregselectvariables",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("multiregvarx")
                                ),
                                column(5,
                                       uiOutput("multiregvary")
                                ),
                                column(2,
                                       actionButton("multiregrun", "Run"),
                                ),
                            )
                            
                        ),
                        conditionalPanel(
                            condition = ("input.multiregrun == 1"),
                            #h3("Summary"),
                            #tableOutput("simpleregout")
                            #verbatimTextOutput("simpleregout"),
                            tabsetPanel(type="tab", 
                                        tabPanel("Summary",
                                                 verbatimTextOutput("multiregsum")),
                                        tabPanel("Structure",
                                                 verbatimTextOutput("multiregstr")),
                                        tabPanel("Data",
                                                 tableOutput("multiregdata")),
                                        tabPanel("Plot",
                                                 verbatimTextOutput("multiregpred"))
                            )
                            
                        ),
                        
                ),
                tabItem(tabName = "simpleregression",
                        div(class = "well", "Simple Regression"),
                        fluidRow(
                            # column allocation for widgets
                            column(6,
                                   fileInput("file","Upload the file"), # fileinput() function is used to get the file upload contorl option
                                   helpText("Default max. file size is 5MB"),
                            ),
                            column(3,
                                   h5(helpText("Select the read.table parameters below")),
                                   checkboxInput(inputId = 'header', label = 'Header', value = TRUE),
                                   checkboxInput(inputId = "stringAsFactors", "stringAsFactors", FALSE),
                                   
                            ),
                            column(3,
                                   radioButtons(inputId = 'sep', label = 'Separator', choices = c(Comma=',',Semicolon=';',Tab='\t', Space=''), selected = ','),
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = "output.fileUploaded",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("varx")
                                       
                                ),
                                column(5,
                                       uiOutput("vary")
                                ),
                                column(2,
                                       uiOutput("simpleregsubmit")
                                ),
                            )
                            
                        ),
                        
                        conditionalPanel(
                            condition = "output.selectvariables",
                            fluidRow(
                                # column allocation for widgets
                                column(5,
                                       uiOutput("simpleregvarx")
                                ),
                                column(5,
                                       uiOutput("simpleregvary")
                                ),
                                column(2,
                                       actionButton("simpleregrun", "Run"),
                                ),
                            )
                            
                        ),
                        conditionalPanel(
                            condition = ("input.simpleregrun == 1"),
                            #h3("Summary"),
                            #tableOutput("simpleregout")
                            #verbatimTextOutput("simpleregout"),
                            tabsetPanel(type="tab", 
                                        tabPanel("Summary",
                                                 verbatimTextOutput("simpleregsum")),
                                        tabPanel("Structure",
                                                 verbatimTextOutput("simpleregstr")),
                                        tabPanel("Data",
                                                 tableOutput("simpleregdata")),
                                        tabPanel("Plot",
                                                 verbatimTextOutput("simpleregpred"))
                            )
                            
                        ),
                        
                ),
                tabItem(tabName = "about", p("This example of about")),
                tabItem(tabName = "dataview", dataTableOutput("viewdata"))
            )
        )
    )
)